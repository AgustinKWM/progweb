var expr = /^[a-zA-Z0-9_\.\-]+@[a-zA-Z0-9\-]+\.[a-zA-z0-9\-\.]+$/;
$(document).ready(function(){
    $("#bEnviar").click(function(){
        var nombre = $("#itNombre").val();
        var correo = $("#itMail").val();
        var asunto = $("#itAsunto").val();

        if(nombre == ""){
            $("#mensaje1").fadeIn();   
        return false;                 
        }else{
            $("#mensaje1").fadeOut();
            if(correo == ""|| !expr.test(correo)){
            $("#mensaje2").fadeIn();
            return false; 
            }else{
                $("#mensaje2").fadeOut();
                if(asunto ==""){
                    $("#mensaje3").fadeIn();
                    return false;
                }
            }       
        }
    });
});

function modooscuro(){
    var body = document.body;
    body.classList.toggle("oscuro");
    var cambio = document.getElementById("cambiarmodo");
    if (body.classList.contains("oscuro")){
        cambio.textContent = "cambiar a modo claro";
    } else {
        cambio.textContent = "cambiar a modo oscuro";
    }
}


$(document).ready(function(){
    $("#modal-container").load("modal.html");
});
